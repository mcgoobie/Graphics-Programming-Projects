Implemented ideas for further development

1.) On ENTER key press, default face on left of canvas changes.

2.) Depending on where the mouse is clicked along the x_axis, average face changes.