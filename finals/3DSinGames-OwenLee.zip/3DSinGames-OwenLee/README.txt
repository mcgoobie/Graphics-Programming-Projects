Implemented ideas for further development

1.)  Changed material of cubes and added 
a red and yellow spotlight shining at 45 degree angles on the left and right.

2.) Added sliders to play with frequency of wave and height of the cubes.