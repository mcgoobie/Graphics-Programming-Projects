Implemented ideas for further development

1.) Changed color of shapes that appear on the grid.

2.) Circles in the grid now pulse in addition to its original function.