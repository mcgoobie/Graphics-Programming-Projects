Implemented ideas for further development

1.) Added grayscale and inversed filters.

2.) Filter loads as sepia as default, arrow keys will change filter.