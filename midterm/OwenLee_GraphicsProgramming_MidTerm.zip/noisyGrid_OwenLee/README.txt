Extra features implemented

1.) Changed color of background and noise

2.) Compass responds to noise and changes color to match