Extra Features Implemented:
  - Score board of asteroids hit
  - Asteroids spawn more frequently as time goes by
  - Customized look of the game.
    - Ship design,
    - Asteroid color,
    - bullet color,
    - environment color